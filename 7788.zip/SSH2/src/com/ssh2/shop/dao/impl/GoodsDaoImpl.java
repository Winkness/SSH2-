package com.ssh2.shop.dao.impl;

import java.sql.SQLException;

import javax.annotation.Resource;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;
import com.ssh2.shop.dao.GoodsDao;
import com.ssh2.shop.model.Goods;
import com.ssh2.shop.model.pageVo.PageBean;



@Repository
public class GoodsDaoImpl extends HibernateDaoSupport implements GoodsDao  {
	
	@Resource(name="sessionFactory")
	public void setHibernateSessionFactroy(SessionFactory sessionFactory){
		this.setSessionFactory(sessionFactory);
	}

	@SuppressWarnings("unchecked")
	@Override
	public PageBean findByPage(String hql, int pagecode, int pagesize, Object[] params) {
		
		return (PageBean) this.getHibernateTemplate().execute(
				new HibernateCallback() {
				public Object doInHibernate(Session session)
				throws HibernateException {
				PageBean pb = new PageBean();
				Query q = session.createQuery(hql);
				for (int i = 0; i < params.length; i++)
				q.setParameter(i, params[i]);
				q.setMaxResults(pagesize);
				q.setFirstResult((pagecode - 1) * pagesize);
				pb.setData(q.list());
				q = session.createQuery("select count(*) "
				+ hql.substring(hql.toLowerCase().indexOf(
				"from")));
				for (int i = 0; i < params.length; i++)
				q.setParameter(i, params[i]);
				pb.setAllcount(Integer.parseInt(String.valueOf(q.uniqueResult())));
				pb.setPagecode(pagecode);
				pb.setPagesize(pagesize);
				return pb;
				}
				});
	}

	@Override
	public Goods findGoodsById(Integer goodsId) {
		Goods goods = this.getHibernateTemplate().get(Goods.class, goodsId);
		return goods;
	}

}
