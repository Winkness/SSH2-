package com.ssh2.shop.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.ssh2.shop.dao.CartsDao;
import com.ssh2.shop.model.Carts;



@Repository
public class CartsDaoImpl extends HibernateDaoSupport implements CartsDao {
	
	@Resource(name="sessionFactory")
	public void setHibernateSessionFactroy(SessionFactory sessionFactory){
		this.setSessionFactory(sessionFactory);
	}

	@Override
	public int addCarts(Carts carts) {
		int count  = (int) this.getHibernateTemplate().save(carts);
		return count;
	}
	
	

	@SuppressWarnings("unchecked")
	@Override
	public Carts findCartsByGoods(Integer goodsId,Integer userId) {
		List<Carts> lists = (List<Carts>) this.getHibernateTemplate().find("select c from Carts c where c.goodsId = "+goodsId + " and c.userId = "+userId);
		if(lists.size() > 0) {
			return lists.get(0);
		}
		return null;
	}

	@Override
	public void updateCarts(Carts carts) {
		this.getHibernateTemplate().update(carts);
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Carts> findAllCarts(Integer userId) {
		List<Carts> lists = (List<Carts>) this.getHibernateTemplate().find("select c from Carts c where c.userId = "+userId);
		return lists;
	}

	@Override
	public void deleteCart(Integer cartId,Integer userId) {
		if(cartId != null) {
			this.getHibernateTemplate().delete(findCartsById(cartId));
		}else {
			this.getHibernateTemplate().bulkUpdate("delete from Carts c where c.userId = "+userId);
		}
		
	}

	@Override
	public Carts findCartsById(Integer cartId) {
		return  this.getHibernateTemplate().load(Carts.class, cartId);
	}

}
