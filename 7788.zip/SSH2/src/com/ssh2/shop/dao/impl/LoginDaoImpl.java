package com.ssh2.shop.dao.impl;

import org.springframework.stereotype.Repository;

import com.ssh2.shop.dao.LoginDao;
import com.ssh2.shop.model.UserInfo;

import java.util.List;

import javax.annotation.Resource;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;


@Repository
public class LoginDaoImpl  extends HibernateDaoSupport implements LoginDao {
	
	@Resource(name="sessionFactory")
	public void setHibernateSessionFactroy(SessionFactory sessionFactory){
		this.setSessionFactory(sessionFactory);
	}

	@Override
	public UserInfo doLoginDao(String username) {
		String sql = "select u from UserInfo u  where u.username = ?";
		List<UserInfo> userlist = (List<UserInfo>) this.getHibernateTemplate().find(sql, username);	
		if(userlist!=null&&userlist.size()>0) {
			return userlist.get(0);
		}
		return null;
	}
}
