package com.ssh2.shop.dao.impl;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;

import com.ssh2.shop.dao.OrderDao;
import com.ssh2.shop.model.UserOrder;

@Repository
public class OrderDaoImpl  extends HibernateDaoSupport implements OrderDao {
	
	@Resource(name="sessionFactory")
	public void setHibernateSessionFactroy(SessionFactory sessionFactory){
		this.setSessionFactory(sessionFactory);
	}

	@Override
	public void addOrder(UserOrder order) {
		this.getHibernateTemplate().save(order);
		
	}

}
