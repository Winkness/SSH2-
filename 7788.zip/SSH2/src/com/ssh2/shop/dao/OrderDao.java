package com.ssh2.shop.dao;

import com.ssh2.shop.model.UserOrder;

public interface OrderDao {

	
	void addOrder(UserOrder order);
}
