package com.ssh2.shop.dao;

import com.ssh2.shop.model.Goods;
import com.ssh2.shop.model.pageVo.PageBean;

public interface GoodsDao {
	
	public PageBean findByPage(String hql,int pagecode,int pagesize,Object[]
			params);

	
	
	Goods findGoodsById(Integer goodsId);

}
