package com.ssh2.shop.dao;

import java.util.List;

import com.ssh2.shop.model.Carts;

public interface CartsDao {
	
	int addCarts(Carts carts);

	Carts findCartsByGoods(Integer goodsId,Integer userId);
	
	void updateCarts(Carts carts);
	
	List<Carts> findAllCarts(Integer userId);
	
	
	void deleteCart(Integer cartId,Integer userId);
	
	Carts findCartsById(Integer cartId);
	
}
