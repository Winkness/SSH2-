package com.ssh2.shop.dao;

import com.ssh2.shop.model.UserInfo;

public interface LoginDao {
	
	UserInfo doLoginDao(String username);
}
