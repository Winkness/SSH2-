package com.ssh2.shop.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name="user_info")
public class UserInfo {
	
	@Id//Ψһid
	@GeneratedValue(generator="mygener")
	@GenericGenerator(name="mygener",strategy="native")
	private int id;
	
	@Column(name="username",length=30,nullable=true,unique=false)
	private String username;
	
	@Column(name="password",length=30,nullable=true,unique=false)
	private String password;
	
	@Column(name="add_time")
	private Date addTime;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getAddTime() {
		return addTime;
	}

	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}

	@Override
	public String toString() {
		return "UserInfo [id=" + id + ", username=" + username + ", password=" + password + ", addTime=" + addTime
				+ "]";
	}

	
	
	
}
