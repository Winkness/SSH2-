package com.ssh2.shop.model.pageVo;

import java.util.ArrayList;
import java.util.List;

public class PageBean {

	private int allcount;
	private int allpage;
	private int pagecode;
	private int pagesize;
	private List data = new ArrayList();

	public int getAllcount() {
		return allcount;
	}

	public void setAllcount(int allcount) {
		this.allcount = allcount;
	}

	public int getAllpage() {
		return allcount % pagesize == 0 ? allcount / pagesize : allcount / pagesize + 1;
	}

	public List getData() {
		return data;
	}

	public void setData(List data) {
		this.data = data;
	}

	public int getPagecode() {
		return pagecode;
	}

	public void setPagecode(int pagecode) {
		this.pagecode = pagecode;
	}

	public int getPagesize() {
		return pagesize;
	}

	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}

}
