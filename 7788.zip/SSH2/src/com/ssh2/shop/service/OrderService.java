package com.ssh2.shop.service;

import com.ssh2.shop.model.UserOrder;

public interface OrderService {

	
	void addOrder(UserOrder order,int orderCode);
}
