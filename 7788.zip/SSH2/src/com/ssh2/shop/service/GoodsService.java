package com.ssh2.shop.service;

import com.ssh2.shop.model.pageVo.PageBean;

public interface GoodsService {
	
	
	public PageBean selectByPage(int pagecode, int pagesize);

}
