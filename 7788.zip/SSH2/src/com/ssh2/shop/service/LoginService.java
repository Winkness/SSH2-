package com.ssh2.shop.service;

import com.ssh2.shop.model.UserInfo;

public interface LoginService {
	
	UserInfo doLogin(String username);

}
