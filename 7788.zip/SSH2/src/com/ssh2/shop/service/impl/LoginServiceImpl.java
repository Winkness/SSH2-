package com.ssh2.shop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ssh2.shop.dao.LoginDao;
import com.ssh2.shop.model.UserInfo;
import com.ssh2.shop.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	private LoginDao loginDao;

	@Override
	public UserInfo doLogin(String username) {
		return loginDao.doLoginDao(username);
	}
	
	

}
