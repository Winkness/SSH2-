package com.ssh2.shop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssh2.shop.dao.GoodsDao;
import com.ssh2.shop.model.pageVo.PageBean;
import com.ssh2.shop.service.GoodsService;


@Service
public class GoodsServiceImpl implements GoodsService {
	
	@Autowired
	private GoodsDao goodsDao;

	@Override
	public PageBean selectByPage(int pagecode, int pagesize) {
		return goodsDao.findByPage("select g from Goods g", pagecode, pagesize,  new Object[] {});
	}

}
