package com.ssh2.shop.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssh2.shop.dao.OrderDao;
import com.ssh2.shop.model.UserOrder;
import com.ssh2.shop.service.OrderService;


@Service
@Transactional
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	private OrderDao orderDao;

	@Override
	public void addOrder(UserOrder order,int orderCode) {
		order.setOrderCode(String.valueOf(orderCode));
		orderDao.addOrder(order);
	}

}
