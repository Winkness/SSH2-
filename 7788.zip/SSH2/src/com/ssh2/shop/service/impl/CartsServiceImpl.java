package com.ssh2.shop.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssh2.shop.dao.CartsDao;
import com.ssh2.shop.dao.GoodsDao;
import com.ssh2.shop.model.Carts;
import com.ssh2.shop.model.Goods;
import com.ssh2.shop.service.CartsService;

@Transactional
@Service
public class CartsServiceImpl implements CartsService {
	
	@Autowired
	private GoodsDao goodsDao;
	
	@Autowired
	private CartsDao cartsDao;

	@Override
	public boolean addCarts(Integer goodsId,Integer userId) {
		Goods goods = goodsDao.findGoodsById(goodsId);
		if(goods != null) {
			Carts carts = new Carts();
			carts.setGoodsId(goods.getId());
			carts.setGoodsName(goods.getGoodsName());
			carts.setGoodsType(goods.getTypeName());
			carts.setUnit(goods.getUnit());
			carts.setPrice(goods.getPrice());
			carts.setNumber(1);
			carts.setCountPrice(goods.getPrice());
			carts.setUserId(userId);
			int count = cartsDao.addCarts(carts);
			if(count > 0) {
				return true;
			}
		}
		return false;
	}

	@Override
	public Carts findCartsByGoods(Integer goodsId,Integer userId) {
		return cartsDao.findCartsByGoods(goodsId,userId);
	}

	
	
	@Override
	public boolean updateCarts(Carts carts) {
		carts.setCountPrice(carts.getPrice().multiply(new BigDecimal(carts.getNumber())));
		cartsDao.updateCarts(carts);
		return true;
	}

	@Override
	public Map<String, Object> findAllCarts(Integer userId) {
		List<Carts> lists = cartsDao.findAllCarts(userId);
		Map<String, Object> map = new HashMap<String, Object>();
		BigDecimal countPrice = new BigDecimal("0");
		if(lists.size() > 0) {
			
			for (Carts carts : lists) {
				countPrice = countPrice.add(carts.getCountPrice());
			}
		}
		map.put("total", countPrice);
		map.put("catList", lists);
		
		return map;
	}

	@Override
	public void deleteCart(Integer cartId, Integer userId) {
		cartsDao.deleteCart(cartId, userId);
	}

	@Override
	public Carts findCartsById(Integer cartId) {
		return cartsDao.findCartsById(cartId);
	}


}
