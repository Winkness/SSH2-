package com.ssh2.shop.service;

import java.util.Map;

import com.ssh2.shop.model.Carts;

public interface CartsService {
	
	boolean addCarts(Integer goodsId,Integer userId);
	
	Carts findCartsByGoods(Integer goodsId,Integer userId);
	
	
	boolean updateCarts(Carts carts);
	
	
	 Map<String, Object>findAllCarts(Integer userId);
	 
	 void deleteCart(Integer cartId,Integer userId);
	 
	 Carts findCartsById(Integer cartId);
}
