package com.ssh2.shop.action;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.alibaba.fastjson.JSON;
import com.opensymphony.xwork2.ActionContext;
import com.ssh2.shop.model.Carts;
import com.ssh2.shop.model.UserOrder;
import com.ssh2.shop.model.UserInfo;
import com.ssh2.shop.service.CartsService;
import com.ssh2.shop.service.OrderService;

@Controller("orderAction")
@Scope("prototype")
public class OrderAction {
	
	@Autowired
	private CartsService cartsService;
	
	@Autowired
	private OrderService orderService;
	
	
	public String addOrder() {
		UserInfo info = (UserInfo) ActionContext.getContext().getSession().get("islogin");
		Map<String, Object> map = cartsService.findAllCarts(info.getId());
		List<Carts> lists = (List<Carts>) map.get("catList");
		int random = (int)((Math.random()*9+1)*10000);
		for (Carts carts : lists) {
			UserOrder order = new UserOrder();
			BeanUtils.copyProperties(carts, order,new String[] {"id"});
			orderService.addOrder(order,random);
		}
		ActionContext.getContext()
		.put("code",random);
		return "success";
	}
	

}
