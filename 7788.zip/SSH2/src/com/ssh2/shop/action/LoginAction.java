package com.ssh2.shop.action;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ModelDriven;
import com.ssh2.shop.model.UserInfo;
import com.ssh2.shop.service.LoginService;

@Controller("loginAction")
@Scope("prototype")
public class LoginAction implements ModelDriven<UserInfo> {
	
	private UserInfo userInfo = new UserInfo();
	
	@Autowired
	private LoginService loginService;
	
	public String doLogin() {
		HttpServletRequest request = ServletActionContext.getRequest();
		UserInfo info = loginService.doLogin(userInfo.getUsername());
		if(info == null) {
			request.setAttribute("loginMsg", "�û�������");
			return "error";
		}
		if(!info.getPassword().equals(userInfo.getPassword())) {
			request.setAttribute("loginMsg", "�������");
			return "error";
		}
		ActionContext.getContext().getSession().put("islogin", info);
		return "success";
	}

	@Override
	public UserInfo getModel() {
		return userInfo;
	}

}
