package com.ssh2.shop.action;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.alibaba.fastjson.JSON;
import com.opensymphony.xwork2.ActionContext;
import com.ssh2.shop.model.pageVo.PageBean;
import com.ssh2.shop.service.GoodsService;

@Controller("googdItemsAction")
@Scope("prototype")
public class GoogdItemsAction {
	
	private int pagecode = 1;

	public int getPagecode() {
		return pagecode;
	}
	public void setPagecode(int pagecode) {
		this.pagecode = pagecode;
	}

	@Autowired
	private GoodsService goodsService;
	
	
	public String getGoodsList() {
		PageBean pageBean = goodsService.selectByPage(pagecode, 5);
		ActionContext.getContext()
		.put("pb",pageBean);
		return  "success";
	}
}
