package com.ssh2.shop.action;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.alibaba.fastjson.JSON;
import com.opensymphony.xwork2.ActionContext;
import com.ssh2.shop.model.Carts;
import com.ssh2.shop.model.UserInfo;
import com.ssh2.shop.service.CartsService;

@Controller("cart	Action")
@Scope("prototype")
public class CartAction {
	
	@Autowired
	private CartsService cartsService;
	
	private Integer prodid;
	private Integer number;
	private Integer cartId;
	
	private int[] cartIds;
	
	private int[] sl;
	
	public Integer getProdid() {
		return prodid;
	}
	public void setProdid(Integer prodid) {
		this.prodid = prodid;
	}
	
	public Integer getNumber() {
		return number;
	}
	public void setNumber(Integer number) {
		this.number = number;
	}
	
	public Integer getCartId() {
		return cartId;
	}
	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}
	
	public int[] getCartIds() {
		return cartIds;
	}
	public void setCartIds(int[] cartIds) {
		this.cartIds = cartIds;
	}
	public int[] getSl() {
		return sl;
	}
	public void setSl(int[] sl) {
		this.sl = sl;
	}
	public String addCart() {
		UserInfo info = (UserInfo) ActionContext.getContext().getSession().get("islogin");
		Carts carts = cartsService.findCartsByGoods(prodid,info.getId());
		if(carts == null) {
			boolean flag = cartsService.addCarts(prodid, info.getId());
			return flag ? "success":"error";
		}else {
			if(number == null) {
				carts.setNumber(carts.getNumber() + 1);
			}else {
				carts.setNumber(number);
			}
			boolean flag = cartsService.updateCarts(carts);
			return flag ? "success":"error";
		}
	}
	
	
	public String findCart() {
		UserInfo info = (UserInfo) ActionContext.getContext().getSession().get("islogin");
		Map<String, Object> map = cartsService.findAllCarts(info.getId());
		ActionContext.getContext()
		.put("total",map.get("total"));
		ActionContext.getContext()
		.put("cart",map.get("catList"));
		return "lists";
	}
	
	
	public String deleteCart() {
		UserInfo info = (UserInfo) ActionContext.getContext().getSession().get("islogin");
		if(cartId == null) {
			cartsService.deleteCart(null, info.getId());
		}else {
			cartsService.deleteCart(cartId, info.getId());
		}
		return "del";
	}
	
	public String updateCart() {	
		for(int i = 0;i < cartIds.length;i++) {
			Carts carts = cartsService.findCartsById(cartIds[i]);
			carts.setNumber(sl[i]);
			carts.setCountPrice(carts.getCountPrice().multiply(new BigDecimal(sl[i])));
			cartsService.updateCarts(carts);
		}
		return "update";
	}

	
	public String gotoCart() {
		UserInfo info = (UserInfo) ActionContext.getContext().getSession().get("islogin");
		Map<String, Object> map = cartsService.findAllCarts(info.getId());
		ActionContext.getContext()
		.put("total",map.get("total"));
		ActionContext.getContext()
		.put("cart",map.get("catList"));
		return "toService";
	}
}
